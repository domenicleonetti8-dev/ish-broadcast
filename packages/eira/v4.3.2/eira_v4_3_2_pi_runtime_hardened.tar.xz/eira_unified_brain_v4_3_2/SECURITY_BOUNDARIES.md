# Security and Safety Boundaries — v4.2

## Secrets
- API keys, OAuth tokens, PATs, and bot tokens are environment-only.
- Example config stores environment variable names, not secret values.
- Audit logging omits prompt/text by default.
- Mutation receipts store argument keys and an argument hash rather than raw sensitive values.
- Known secret-token forms are redacted before unsafe diagnostic propagation.
- External evidence is secret-redacted before it is wrapped and passed to another specialist.
- Audit logs redact credential-shaped secrets even when text logging is explicitly enabled.
- Executable-blueprint jobs receive a stripped environment by default instead of inheriting host credentials.

## Current-turn authority
- Stale history cannot authorize a tool, provider, connection, code run, or mutation.
- An explicit current-turn instruction may authorize the specifically named action inside its bounded policy.
- A semantic intent advisor may suggest a non-mutating capability only for ambiguous safe-default turns.
- Social fast paths and deterministic mutation rules cannot be overridden by that advisor.
- Missing referenced continuity produces a warning/re-check state instead of guessed prior facts.

## Untrusted external content
- Web pages, files, email bodies, tool outputs, and provider prose are evidence/data, not instructions.
- Prompt-injection-like content cannot change identity, system rules, permissions, or the current user goal.
- Cross-step workflow evidence is wrapped as untrusted data before another specialist sees it.
- URL visit/fetch paths block loopback/private/link-local/reserved IP targets by default unless a separately bounded local-native adapter explicitly requires a local endpoint.

## External writes and connection actions
- Mutating service operations require current-turn authorization.
- Missing required write arguments cause clarification.
- Mutation calls receive deterministic idempotency keys.
- A successful mutation gets a hashed action receipt; response integrity rejects a success claim without one.
- Provider/service/native-adapter failures remain failures; no success is fabricated.
- Bluetooth broadcast is outside unified_brain_ai. Any future external connector must return native evidence; BLE/GATT advertising is never upgraded into a Classic A2DP success claim.
- `ask`, `trusted_auto`, and `auto` connection modes remain policy-controlled; explicit current-turn device wording can authorize that named action only.

## Executable blueprint and engineering boundaries
- Executable blueprints are staging-first and reject absolute/path-escape/symlink-parent writes.
- Commands are explicit argv arrays; free-form shell interpolation is not the blueprint execution contract.
- Python candidates compile before execution.
- Seed auto-execution requires a verified seed, while each instantiated code payload is still compiled and verified independently.
- The staging directory is a path/permission boundary, **not a kernel/VM sandbox**; executed programs still operate with the OS permissions of the Eira process.
- Verified engineering may promote a fully verified candidate into an allowlisted extension target only through its atomic backup/hash/receipt promoter.
- Verified engineering may not promote into Eira core, identity, voice, router, memory, reasoning, or `extensions/unified_brain_ai` itself.
- The improvement/evolution lab never self-promotes a candidate directly into LIVE; it produces benchmarked, verified improvements that must cross the separate promotion boundary.

## 3D science and architectural boundaries
- Geometry/connectivity/material calculations preserve provenance and uncertainty.
- Current built-in physics checks are preliminary closed-form calculations, not FEA/CFD, fatigue, thermal, seismic, geotechnical, code certification, prototype testing, or professional sign-off.
- Representative material properties do not replace the exact grade/product/batch manufacturer data required for final engineering decisions.
- Architectural mode requires jurisdiction, site conditions, and design load cases before code-relevant conclusions are allowed.
- Future-science mode requires explicit hypotheses and remains labeled hypothesis-only; it cannot be presented as established science.

## Evidence and outward response
- Provider prose alone is lower-trust evidence, not verification.
- Grounded tasks require structured grounded/tool evidence.
- Engineering requires verification evidence.
- Final provider/Jellyfish/native results always return through Eira host synthesis.
- Response-integrity checks detect provider identity leakage, false success, missing mutation receipts, and stale-topic leakage.
- Operational truth receipts are hash chained and contain no hidden chain-of-thought.

## Memory
- Providers and Jellyfish cannot directly write permanent Eira memory.
- Scratch context is request-scoped and purged.
- Permanent memory writes happen only after final synthesis.
- Memory supports expiry, supersession, explicit forgetting, and active/inactive state rather than silent deletion of history.

## Resource boundaries
- Heavy provider concurrency defaults to one.
- Provider health is lazy; no continuous model polling.
- Provider attempts and per-turn remote/heavy/cost/wall-clock usage are bounded.
- Dynamic plans are step-bounded and acyclic.

## Explicit exclusions
- No fake Bluetooth speaker-side client architecture.
- No internal Bluetooth/broadcast-audio provider or hidden fallback. No claim that BLE/GATT alone provides generic multi-speaker Classic A2DP audio.
- No hidden unrelated-capability fallback.
- No provider, worker, or voice engine as outward Eira identity.
- No unrestricted recursive self-rewrite or self-promotion.
- No scientific/architectural certification claim from a generated 3D model alone.

## Agency boundary (v4.3)
Operational experience is secret-redacted and raw request text is disabled by default. Self-generated goals do not grant permission. Autonomous activity is limited to local read-only or staged work. External writes/hardware actions retain current-turn authorization rules. Eira identity/core and `unified_brain_ai` cannot be silently self-rewritten.


## v4.3.2 network/deployment additions

- User-controlled URL hostnames are DNS-resolved and every answer is checked; private/loopback/link-local/multicast/unspecified/reserved answers fail closed.
- URL userinfo is rejected. DNS errors fail closed.
- Native voice endpoint servers default to loopback; non-loopback binding requires a bearer token.
- Multipart uploads have a local default cap of 64 MiB, overridable by `EIRA_HTTP_MAX_MULTIPART_BYTES`.
- The installer rejects symlinked protected paths, proves path containment, serializes installs with a lock, checks disk capacity, verifies package hashes, hashes protected LIVE files before/after, and rolls back on failure.
