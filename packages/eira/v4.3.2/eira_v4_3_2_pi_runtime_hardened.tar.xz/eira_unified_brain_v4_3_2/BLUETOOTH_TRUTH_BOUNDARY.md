# Bluetooth truth boundary — external project

As of Unified Brain v4.3.2, Bluetooth broadcast is **not an internal Eira capability**. The standalone project is `domenicleonetti8-dev/ish-broadcast`, last evidence-pinned here at master commit `de4ad62b3cdc52c87d5ca4a316a03bad51351075`.

The referenced source includes a CoreBluetooth advertising/device bridge. CoreBluetooth is BLE/GATT-class API surface. That source does **not** by itself prove a generic Bluetooth Classic A2DP virtual speaker, simultaneous generic multi-speaker A2DP routing, or a bypass of iOS audio-route limits. Any future claim of real audio connection requires native target evidence.

Unified Brain v4.3.2 therefore contains no `bluetooth_control` provider, no `bluetooth_*` runtime capabilities, no `broadcast_audio` Spotify operation, no speaker socket fallback, and no embedded `native/ish_broadcast` runtime/source tree. The full self-contained installer preserves old source/history in a continuity vault only. Eira may discuss that external project in the normal conversation lane, but the unified brain will not fake control of it.
