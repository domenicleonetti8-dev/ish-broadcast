# Eira Bigger Picture — v4.3.2

Eira is a persistent single-identity assistant platform, not a provider wrapper. The unified brain exists to let one executive converse, reason, use verified specialists, remember selectively, learn from evidence, operate under explicit authority, and support the long-lived universe/engineering program without allowing any subsystem to become the outward identity.

The architectural north star is: current turn first; one outward Eira; request-scoped scratch; governed permanent memory; evidence before claims; local/on-demand resources; tools/providers as specialists; mutation authority explicit; verified engineering isolated; experience separate from conversation memory; bounded agency without self-granted permission; native hardware truth boundaries; reversible deployment; continuity records preserved across versions.

Terra Prime and the OASIS-style universe are first-class long-horizon project continuity, but they remain content/simulation layers rather than a reason to couple renderer state into conversational identity or routing. The standalone ish-broadcast project is likewise external: it may eventually be controlled through a proven connector, but it is not part of Eira's brain.

## Native spatial truth closure (4.3.2 final hardening)

The complete source bundle contains a native iOS ARKit + Vision endpoint under `native/ios_spatial/`, not merely a Pi-side placeholder. Scene reconstruction is enabled only after native support checks; scene depth is enabled only after frame-semantic support checks. Eira receives compact structured scene summaries, not persisted raw camera/depth buffers. The Pi accepts LiDAR success only from a response that positively identifies a native Apple spatial framework and reports LiDAR support.

The external `ish-broadcast` repository remains the owner of Bluetooth. `native/ios_endpoint/apply_all_to_ish.py` can explicitly attach Eira voice/spatial device bridges to that same iSH host, but it does not register Bluetooth as an Eira unified-brain capability.
